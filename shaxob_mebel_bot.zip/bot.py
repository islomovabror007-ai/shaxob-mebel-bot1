"""
Shaxob Mebel — Telegram bot (aiogram 3 + SQLite)
Mijozlar: katalog ko'rish, buyurtma berish (o'lcham, rang, telefon).
Admin (sotuvchi/usta): mebel qo'shish/o'chirish, buyurtmalarni boshqarish, xabar yuborish, zaxira nusxa.
"""
import asyncio
import html
import logging
import os
import re
from datetime import datetime

import aiosqlite
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart, Filter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BotCommand, CallbackQuery, FSInputFile, InputMediaPhoto, KeyboardButton,
    Message, ReplyKeyboardMarkup, ReplyKeyboardRemove, TelegramObject,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()

# ----------------------------- SOZLAMALAR -----------------------------
BOT_TOKEN = os.getenv("BOT_TOKEN", "8622894523:AAFAvaPIQ-fQbj7aJgA7Dq20wEz3db0qtiM").strip()
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "6760281987, 5691078089, 6872071176, 8930775969, 7710683691").replace(" ", "").split(",") if x.isdigit()}
DB_PATH = os.getenv("DB_PATH", "data/shaxob.db")
PHONE = os.getenv("PHONE", "+998 91 331 9611, +998 93 510 2223, +998 94 198 1150, +998 97 818 9199, +998 93 148 1903 ")
ADDRESS = os.getenv("ADDRESS", "Navoiy viloyati Xatirchi tumani")
WORKTIME = os.getenv("WORKTIME", "Har kuni 09:00 - 20:00")
MAP_URL = os.getenv("MAP_URL", "https://maps.app.goo.gl/4UhTRKM6KTSsruNZ7").strip()
INSTAGRAM = os.getenv("INSTAGRAM", "https://www.instagram.com/shaxob_mebil?srtk=ejdicmw1a2tndzlw").strip()

BRAND = "Shaxob Mebel"
CATEGORIES = [
    "🛏 Yotoqxona", "🛋 Mehmonxona", "🍽 Oshxona",
    "💼 Ofis mebellari", "🧸 Bolalar xonasi", "🚪 Shkaf va boshqa",
]
STATUS = {
    "new": "🆕 Yangi",
    "accepted": "✅ Qabul qilindi",
    "work": "🔨 Ishlanmoqda",
    "done": "🏁 Tayyor",
    "cancel": "❌ Bekor qilindi",
}

# Tugma matnlari
B_CATALOG = "🛋 Katalog"
B_ORDER = "🛒 Buyurtma berish"
B_MYORD = "📦 Buyurtmalarim"
B_CONTACT = "📞 Aloqa"
B_ABOUT = "ℹ️ Biz haqimizda"
B_HELP = "❓ Yordam"
B_ADMIN = "🛠 Admin panel"
B_CANCEL = "❌ Bekor qilish"
B_SKIP = "⏭ O'tkazib yuborish"
B_SEND_PHONE = "📱 Raqamimni yuborish"
A_ADD = "➕ Mebel qo'shish"
A_ACTIVE = "🆕 Faol buyurtmalar"
A_ALL = "📋 Oxirgi buyurtmalar"
A_STATS = "📊 Statistika"
A_BROADCAST = "📢 Xabar yuborish"
A_BACKUP = "💾 Zaxira nusxa"
A_HOME = "🏠 Asosiy menyu"

router = Router()


# ----------------------------- YORDAMCHILAR ---------------------------
def esc(text) -> str:
    return html.escape(str(text)) if text is not None else ""


def now() -> str:
    return datetime.now().strftime("%d.%m.%Y %H:%M")


class IsAdmin(Filter):
    async def __call__(self, event: TelegramObject) -> bool:
        user = getattr(event, "from_user", None)
        return bool(user and user.id in ADMIN_IDS)


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ----------------------------- BAZA -----------------------------------
async def init_db() -> None:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users(
                user_id INTEGER PRIMARY KEY, full_name TEXT, username TEXT, joined TEXT);
            CREATE TABLE IF NOT EXISTS items(
                id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, category TEXT,
                price TEXT, description TEXT, photo TEXT, created_at TEXT);
            CREATE TABLE IF NOT EXISTS orders(
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT,
                full_name TEXT, item_id INTEGER, title TEXT, photo TEXT, size TEXT,
                color TEXT, phone TEXT, comment TEXT, status TEXT DEFAULT 'new',
                created_at TEXT);
            """
        )
        await db.commit()


async def q_all(sql: str, args=()):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(sql, args)
        return await cur.fetchall()


async def q_one(sql: str, args=()):
    rows = await q_all(sql, args)
    return rows[0] if rows else None


async def q_run(sql: str, args=()) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(sql, args)
        await db.commit()
        return cur.lastrowid


# ----------------------------- KLAVIATURALAR --------------------------
def main_kb(user_id: int) -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text=B_CATALOG), KeyboardButton(text=B_ORDER))
    kb.row(KeyboardButton(text=B_MYORD), KeyboardButton(text=B_CONTACT))
    kb.row(KeyboardButton(text=B_ABOUT), KeyboardButton(text=B_HELP))
    if is_admin(user_id):
        kb.row(KeyboardButton(text=B_ADMIN))
    return kb.as_markup(resize_keyboard=True)


def admin_kb() -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text=A_ADD), KeyboardButton(text=B_CATALOG))
    kb.row(KeyboardButton(text=A_ACTIVE), KeyboardButton(text=A_ALL))
    kb.row(KeyboardButton(text=A_STATS), KeyboardButton(text=A_BROADCAST))
    kb.row(KeyboardButton(text=A_BACKUP), KeyboardButton(text=A_HOME))
    return kb.as_markup(resize_keyboard=True)


def cancel_kb(extra: list[KeyboardButton] | None = None) -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    if extra:
        kb.row(*extra)
    kb.row(KeyboardButton(text=B_CANCEL))
    return kb.as_markup(resize_keyboard=True)


async def categories_kb() -> InlineKeyboardBuilder:
    counts = {r["category"]: r["c"] for r in await q_all(
        "SELECT category, COUNT(*) c FROM items GROUP BY category")}
    kb = InlineKeyboardBuilder()
    for i, name in enumerate(CATEGORIES):
        kb.button(text=f"{name} ({counts.get(name, 0)})", callback_data=f"cat:{i}")
    kb.adjust(2)
    return kb


# ----------------------------- HOLATLAR (FSM) -------------------------
class OrderForm(StatesGroup):
    what = State()
    size = State()
    color = State()
    phone = State()
    comment = State()
    confirm = State()


class AddItem(StatesGroup):
    photo = State()
    title = State()
    category = State()
    price = State()
    description = State()


class Broadcast(StatesGroup):
    text = State()


# ----------------------------- UMUMIY BUYRUQLAR -----------------------
WELCOME = (
    "Assalomu alaykum, <b>{name}</b>! 👋\n\n"
    "<b>🪑 Shaxob Mebel</b> botiga xush kelibsiz!\n"
    "Bu yerda siz bizning tayyor mebellarimizni ko'rishingiz va o'zingizga "
    "kerakli o'lcham hamda rangda buyurtma berishingiz mumkin.\n\n"
    "Quyidagi menyudan tanlang 👇"
)

HELP_TEXT = (
    "<b>❓ Yordam</b>\n\n"
    "/start — botni boshlash\n"
    "/menu — asosiy menyu\n"
    "/catalog — mebellar katalogi\n"
    "/order — buyurtma berish\n"
    "/contact — aloqa va manzil\n"
    "/help — yordam\n"
    "/cancel — joriy amalni bekor qilish\n\n"
    "<b>Buyurtma qanday beriladi?</b>\n"
    "1) Katalogdan mebelni tanlang yoki «Buyurtma berish» tugmasini bosing\n"
    "2) O'lcham, rang va telefon raqamingizni yozing\n"
    "3) Buyurtma sotuvchiga yuboriladi va u siz bilan bog'lanadi ✅"
)


@router.message(CommandStart())
async def cmd_start(m: Message, state: FSMContext):
    await state.clear()
    u = m.from_user
    await q_run(
        "INSERT INTO users(user_id, full_name, username, joined) VALUES(?,?,?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET full_name=excluded.full_name, username=excluded.username",
        (u.id, u.full_name, u.username, now()),
    )
    await m.answer(WELCOME.format(name=esc(u.first_name)), reply_markup=main_kb(u.id))


@router.message(Command("menu"))
@router.message(F.text == A_HOME)
async def cmd_menu(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🏠 Asosiy menyu", reply_markup=main_kb(m.from_user.id))


@router.message(Command("help"))
@router.message(F.text == B_HELP)
async def cmd_help(m: Message):
    await m.answer(HELP_TEXT)


@router.message(Command("cancel"))
@router.message(F.text == B_CANCEL)
async def cmd_cancel(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Bekor qilindi.", reply_markup=main_kb(m.from_user.id))


@router.message(Command("contact"))
@router.message(F.text == B_CONTACT)
async def cmd_contact(m: Message):
    text = (
        f"<b>📞 Aloqa — {BRAND}</b>\n\n"
        f"☎️ Telefon: <b>{esc(PHONE)}</b>\n"
        f"📍 Manzil: {esc(ADDRESS)}\n"
        f"🕘 Ish vaqti: {esc(WORKTIME)}"
    )
    if INSTAGRAM:
        text += f"\n📸 Instagram: {esc(INSTAGRAM)}"
    if MAP_URL:
        text += f'\n🗺 <a href="{esc(MAP_URL)}">Xaritada ochish</a>'
    await m.answer(text, disable_web_page_preview=True)


@router.message(F.text == B_ABOUT)
async def about(m: Message):
    await m.answer(
        f"<b>🪑 {BRAND}</b>\n\n"
        "Biz o'z sexda sifatli mebellar ishlab chiqaramiz: yotoqxona, mehmonxona, "
        "oshxona, ofis va bolalar mebellari. Buyurtma asosida o'lcham va rang bo'yicha "
        "tayyorlab beramiz.\n\n"
        "✅ Sifatli material\n✅ Buyurtma bo'yicha o'lcham va rang\n"
        "✅ O'z vaqtida yetkazib berish\n\n"
        f"Savollar uchun: {esc(PHONE)}"
    )


# ----------------------------- KATALOG --------------------------------
@router.message(Command("catalog"))
@router.message(F.text == B_CATALOG)
async def show_catalog(m: Message):
    kb = await categories_kb()
    await m.answer("🛋 <b>Katalog</b>\nBo'limni tanlang:", reply_markup=kb.as_markup())


@router.callback_query(F.data == "cats")
async def cb_cats(c: CallbackQuery):
    kb = await categories_kb()
    text = "🛋 <b>Katalog</b>\nBo'limni tanlang:"
    if c.message.photo:
        await c.message.delete()
        await c.message.answer(text, reply_markup=kb.as_markup())
    else:
        await c.message.edit_text(text, reply_markup=kb.as_markup())
    await c.answer()


@router.callback_query(F.data == "noop")
async def cb_noop(c: CallbackQuery):
    await c.answer()


def item_caption(it, pos: int, total: int) -> str:
    price = f"\n💰 Narxi: <b>{esc(it['price'])}</b>" if it["price"] else ""
    desc = f"\n\n{esc(it['description'])}" if it["description"] else ""
    return f"<b>{esc(it['title'])}</b>\n{esc(it['category'])}{price}{desc}\n\n📦 {pos}/{total}"


async def render_item(c: CallbackQuery, cat_idx: int, offset: int):
    cat = CATEGORIES[cat_idx]
    row = await q_one("SELECT COUNT(*) c FROM items WHERE category=?", (cat,))
    total = row["c"]
    if total == 0:
        await c.answer("Bu bo'limda hozircha mebel yo'q", show_alert=True)
        return
    offset %= total
    it = (await q_all(
        "SELECT * FROM items WHERE category=? ORDER BY id DESC LIMIT 1 OFFSET ?",
        (cat, offset)))[0]
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️", callback_data=f"it:{cat_idx}:{(offset - 1) % total}")
    kb.button(text=f"{offset + 1}/{total}", callback_data="noop")
    kb.button(text="▶️", callback_data=f"it:{cat_idx}:{(offset + 1) % total}")
    kb.button(text="🛒 Shuni buyurtma qilish", callback_data=f"ord:{it['id']}")
    if is_admin(c.from_user.id):
        kb.button(text="🗑 O'chirish", callback_data=f"del:{it['id']}:{cat_idx}:{offset}")
    kb.button(text="⬅️ Bo'limlar", callback_data="cats")
    kb.adjust(3, 1, 1, 1)
    caption = item_caption(it, offset + 1, total)
    try:
        if c.message.photo:
            await c.message.edit_media(
                InputMediaPhoto(media=it["photo"], caption=caption, parse_mode=ParseMode.HTML),
                reply_markup=kb.as_markup())
        else:
            await c.message.delete()
            await c.message.answer_photo(it["photo"], caption=caption, reply_markup=kb.as_markup())
    except TelegramBadRequest:
        pass
    await c.answer()


@router.callback_query(F.data.startswith("cat:"))
async def cb_category(c: CallbackQuery):
    await render_item(c, int(c.data.split(":")[1]), 0)


@router.callback_query(F.data.startswith("it:"))
async def cb_item(c: CallbackQuery):
    _, cat_idx, offset = c.data.split(":")
    await render_item(c, int(cat_idx), int(offset))


# ----------------------------- O'CHIRISH (admin) ----------------------
@router.callback_query(IsAdmin(), F.data.startswith("del:"))
async def cb_del(c: CallbackQuery):
    _, item_id, cat_idx, offset = c.data.split(":")
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Ha, o'chirish", callback_data=f"dely:{item_id}")
    kb.button(text="↩️ Yo'q", callback_data=f"it:{cat_idx}:{offset}")
    kb.adjust(2)
    await c.message.edit_reply_markup(reply_markup=kb.as_markup())
    await c.answer("O'chirishni tasdiqlang")


@router.callback_query(IsAdmin(), F.data.startswith("dely:"))
async def cb_del_yes(c: CallbackQuery):
    await q_run("DELETE FROM items WHERE id=?", (int(c.data.split(":")[1]),))
    await c.message.delete()
    kb = await categories_kb()
    await c.message.answer("🗑 Mebel o'chirildi.\n\n🛋 <b>Katalog</b>", reply_markup=kb.as_markup())
    await c.answer("O'chirildi")


# ----------------------------- BUYURTMA -------------------------------
def normalize_phone(text: str) -> str | None:
    digits = re.sub(r"\D", "", text or "")
    if len(digits) == 9:
        return "+998" + digits
    if len(digits) == 12 and digits.startswith("998"):
        return "+" + digits
    return None


@router.message(Command("order"))
@router.message(F.text == B_ORDER)
async def order_custom(m: Message, state: FSMContext):
    await state.clear()
    await state.update_data(item_id=None, title=None, photo=None)
    await state.set_state(OrderForm.what)
    await m.answer(
        "🛒 <b>Yangi buyurtma</b>\n\nQanday mebel kerak? (masalan: 2 eshikli shkaf, divan, oshxona garnituri)",
        reply_markup=cancel_kb())


@router.callback_query(F.data.startswith("ord:"))
async def order_from_item(c: CallbackQuery, state: FSMContext):
    item = await q_one("SELECT * FROM items WHERE id=?", (int(c.data.split(":")[1]),))
    if not item:
        await c.answer("Bu mebel topilmadi", show_alert=True)
        return
    await state.clear()
    await state.update_data(item_id=item["id"], title=item["title"], photo=item["photo"])
    await state.set_state(OrderForm.size)
    await c.message.answer(
        f"🛒 Siz tanladingiz: <b>{esc(item['title'])}</b>\n\n"
        "📏 Kerakli <b>o'lchamni</b> yozing (eni × bo'yi × balandligi, masalan: 200×60×220 sm)\n"
        "Bilmasangiz «Standart» deb yozing.",
        reply_markup=cancel_kb())
    await c.answer()


@router.message(OrderForm.what, F.text)
async def order_what(m: Message, state: FSMContext):
    await state.update_data(title=m.text[:200])
    await state.set_state(OrderForm.size)
    await m.answer(
        "📏 Kerakli <b>o'lchamni</b> yozing (eni × bo'yi × balandligi, masalan: 200×60×220 sm)\n"
        "Bilmasangiz «Standart» deb yozing.")


@router.message(OrderForm.size, F.text)
async def order_size(m: Message, state: FSMContext):
    await state.update_data(size=m.text[:200])
    await state.set_state(OrderForm.color)
    await m.answer("🎨 Qaysi <b>rangda</b> bo'lsin? (masalan: oq, wenge, yong'oq, kulrang)")


@router.message(OrderForm.color, F.text)
async def order_color(m: Message, state: FSMContext):
    await state.update_data(color=m.text[:200])
    await state.set_state(OrderForm.phone)
    await m.answer(
        "📞 Siz bilan bog'lanish uchun <b>telefon raqamingiz</b>ni yuboring.\n"
        "Pastdagi tugmani bosing yoki raqamni yozing (90 123 45 67).",
        reply_markup=cancel_kb([KeyboardButton(text=B_SEND_PHONE, request_contact=True)]))


@router.message(OrderForm.phone, F.contact)
async def order_phone_contact(m: Message, state: FSMContext):
    digits = re.sub(r"\D", "", m.contact.phone_number)
    await state.update_data(phone="+" + digits)
    await ask_comment(m, state)


@router.message(OrderForm.phone, F.text)
async def order_phone_text(m: Message, state: FSMContext):
    phone = normalize_phone(m.text)
    if not phone:
        await m.answer("⚠️ Raqam noto'g'ri. Iltimos, qayta yozing (masalan: 90 123 45 67).")
        return
    await state.update_data(phone=phone)
    await ask_comment(m, state)


async def ask_comment(m: Message, state: FSMContext):
    await state.set_state(OrderForm.comment)
    await m.answer(
        "💬 Qo'shimcha <b>izoh</b> bo'lsa yozing (manzil, istaklar, rasm...).\nYo'q bo'lsa «O'tkazib yuborish» ni bosing.",
        reply_markup=cancel_kb([KeyboardButton(text=B_SKIP)]))


@router.message(OrderForm.comment, F.text)
async def order_comment(m: Message, state: FSMContext):
    await state.update_data(comment="" if m.text == B_SKIP else m.text[:500])
    d = await state.get_data()
    await state.set_state(OrderForm.confirm)
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Yuborish", callback_data="ocf:yes")
    kb.button(text="❌ Bekor qilish", callback_data="ocf:no")
    kb.adjust(2)
    await m.answer("Tekshirib ko'ring 👇", reply_markup=ReplyKeyboardRemove())
    await m.answer(
        "<b>🧾 Buyurtmangiz</b>\n\n"
        f"🪑 Mebel: <b>{esc(d['title'])}</b>\n"
        f"📏 O'lcham: {esc(d['size'])}\n"
        f"🎨 Rang: {esc(d['color'])}\n"
        f"📞 Telefon: {esc(d['phone'])}\n"
        f"💬 Izoh: {esc(d.get('comment') or '—')}",
        reply_markup=kb.as_markup())


def order_text(o) -> str:
    user_link = f'<a href="tg://user?id={o["user_id"]}">{esc(o["full_name"])}</a>'
    uname = f" (@{esc(o['username'])})" if o["username"] else ""
    return (
        f"🧾 <b>Buyurtma #{o['id']}</b> — {STATUS[o['status']]}\n\n"
        f"👤 {user_link}{uname}\n"
        f"📞 <b>{esc(o['phone'])}</b>\n"
        f"🪑 Mebel: <b>{esc(o['title'])}</b>\n"
        f"📏 O'lcham: {esc(o['size'])}\n"
        f"🎨 Rang: {esc(o['color'])}\n"
        f"💬 Izoh: {esc(o['comment'] or '—')}\n"
        f"🕒 {esc(o['created_at'])}"
    )


def status_kb(order_id: int):
    kb = InlineKeyboardBuilder()
    for key in ("accepted", "work", "done", "cancel"):
        kb.button(text=STATUS[key], callback_data=f"st:{order_id}:{key}")
    kb.adjust(2)
    return kb.as_markup()


@router.callback_query(OrderForm.confirm, F.data.startswith("ocf:"))
async def order_confirm(c: CallbackQuery, state: FSMContext, bot: Bot):
    if c.data.endswith("no"):
        await state.clear()
        await c.message.edit_text("❌ Buyurtma bekor qilindi.")
        await c.message.answer("Asosiy menyu", reply_markup=main_kb(c.from_user.id))
        await c.answer()
        return
    d = await state.get_data()
    await state.clear()
    u = c.from_user
    oid = await q_run(
        "INSERT INTO orders(user_id, username, full_name, item_id, title, photo, size, color, "
        "phone, comment, status, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (u.id, u.username, u.full_name, d.get("item_id"), d["title"], d.get("photo"),
         d["size"], d["color"], d["phone"], d.get("comment", ""), "new", now()))
    order = await q_one("SELECT * FROM orders WHERE id=?", (oid,))
    await c.message.edit_text(
        f"✅ <b>Buyurtmangiz qabul qilindi!</b> (№{oid})\n\n"
        "Sotuvchi tez orada siz bilan bog'lanadi. Rahmat! 🙏")
    await c.message.answer("Asosiy menyu", reply_markup=main_kb(u.id))
    await c.answer()
    await notify_admins(bot, order)


async def notify_admins(bot: Bot, order) -> None:
    if not ADMIN_IDS:
        logging.warning("ADMIN_IDS bo'sh — buyurtma hech kimga yuborilmadi!")
    for admin_id in ADMIN_IDS:
        try:
            if order["photo"]:
                await bot.send_photo(admin_id, order["photo"], caption=order_text(order),
                                     reply_markup=status_kb(order["id"]))
            else:
                await bot.send_message(admin_id, order_text(order), reply_markup=status_kb(order["id"]))
        except Exception as e:  # noqa: BLE001
            logging.error("Adminga yuborib bo'lmadi %s: %s", admin_id, e)


@router.callback_query(IsAdmin(), F.data.startswith("st:"))
async def change_status(c: CallbackQuery, bot: Bot):
    _, oid, key = c.data.split(":")
    await q_run("UPDATE orders SET status=? WHERE id=?", (key, int(oid)))
    order = await q_one("SELECT * FROM orders WHERE id=?", (int(oid),))
    try:
        if c.message.photo:
            await c.message.edit_caption(caption=order_text(order), reply_markup=status_kb(order["id"]))
        else:
            await c.message.edit_text(order_text(order), reply_markup=status_kb(order["id"]))
    except TelegramBadRequest:
        pass
    try:
        await bot.send_message(
            order["user_id"],
            f"📦 Sizning <b>№{order['id']}</b> buyurtmangiz holati: <b>{STATUS[key]}</b>")
    except Exception:  # noqa: BLE001
        pass
    await c.answer("Holat yangilandi")


@router.message(F.text == B_MYORD)
async def my_orders(m: Message):
    rows = await q_all("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 10", (m.from_user.id,))
    if not rows:
        await m.answer("Sizda hali buyurtma yo'q. «🛒 Buyurtma berish» tugmasini bosing.")
        return
    lines = [f"<b>📦 Buyurtmalaringiz</b>\n"]
    for o in rows:
        lines.append(f"№{o['id']} • {esc(o['title'])} • {STATUS[o['status']]}\n   🕒 {esc(o['created_at'])}")
    await m.answer("\n".join(lines))


# ----------------------------- ADMIN PANEL ----------------------------
@router.message(IsAdmin(), Command("admin"))
@router.message(IsAdmin(), F.text == B_ADMIN)
async def admin_panel(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🛠 <b>Admin panel</b>", reply_markup=admin_kb())


# --- Mebel qo'shish ---
@router.message(IsAdmin(), F.text == A_ADD)
async def add_start(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(AddItem.photo)
    await m.answer("📸 Mebel <b>rasmini</b> yuboring (bitta rasm).", reply_markup=cancel_kb())


@router.message(IsAdmin(), AddItem.photo, F.photo)
async def add_photo(m: Message, state: FSMContext):
    await state.update_data(photo=m.photo[-1].file_id)
    await state.set_state(AddItem.title)
    await m.answer("✏️ Mebel <b>nomini</b> yozing (masalan: «Klassik 3 eshikli shkaf»).")


@router.message(IsAdmin(), AddItem.photo)
async def add_photo_bad(m: Message):
    await m.answer("⚠️ Iltimos, rasm yuboring (fayl emas, oddiy rasm).")


@router.message(IsAdmin(), AddItem.title, F.text)
async def add_title(m: Message, state: FSMContext):
    await state.update_data(title=m.text[:100])
    await state.set_state(AddItem.category)
    kb = InlineKeyboardBuilder()
    for i, name in enumerate(CATEGORIES):
        kb.button(text=name, callback_data=f"addcat:{i}")
    kb.adjust(2)
    await m.answer("🗂 Qaysi bo'limga qo'shamiz?", reply_markup=kb.as_markup())


@router.callback_query(IsAdmin(), AddItem.category, F.data.startswith("addcat:"))
async def add_category(c: CallbackQuery, state: FSMContext):
    idx = int(c.data.split(":")[1])
    await state.update_data(category=CATEGORIES[idx])
    await state.set_state(AddItem.price)
    await c.message.edit_text(f"Bo'lim: <b>{CATEGORIES[idx]}</b>")
    await c.message.answer(
        "💰 <b>Narxini</b> yozing (masalan: 2 500 000 so'm). Narx ko'rsatmaslik uchun «O'tkazib yuborish».",
        reply_markup=cancel_kb([KeyboardButton(text=B_SKIP)]))
    await c.answer()


@router.message(IsAdmin(), AddItem.price, F.text)
async def add_price(m: Message, state: FSMContext):
    await state.update_data(price="" if m.text == B_SKIP else m.text[:60])
    await state.set_state(AddItem.description)
    await m.answer(
        "📝 Mebel haqida <b>izoh</b> yozing (material, o'lcham, rang, afzalliklari). Maks. 600 belgi.",
        reply_markup=cancel_kb([KeyboardButton(text=B_SKIP)]))


@router.message(IsAdmin(), AddItem.description, F.text)
async def add_description(m: Message, state: FSMContext):
    d = await state.get_data()
    desc = "" if m.text == B_SKIP else m.text[:600]
    await q_run(
        "INSERT INTO items(title, category, price, description, photo, created_at) VALUES(?,?,?,?,?,?)",
        (d["title"], d["category"], d.get("price", ""), desc, d["photo"], now()))
    await state.clear()
    await m.answer_photo(
        d["photo"],
        caption=f"✅ <b>Mebel qo'shildi!</b>\n\n<b>{esc(d['title'])}</b>\n{esc(d['category'])}\n{esc(d.get('price', ''))}\n\n{esc(desc)}",
        reply_markup=admin_kb())


# --- Buyurtmalar ---
@router.message(IsAdmin(), F.text == A_ACTIVE)
async def admin_active(m: Message, bot: Bot):
    rows = await q_all(
        "SELECT * FROM orders WHERE status IN ('new','accepted','work') ORDER BY id DESC LIMIT 10")
    if not rows:
        await m.answer("Faol buyurtmalar yo'q ✅")
        return
    for o in rows:
        if o["photo"]:
            await m.answer_photo(o["photo"], caption=order_text(o), reply_markup=status_kb(o["id"]))
        else:
            await m.answer(order_text(o), reply_markup=status_kb(o["id"]))


@router.message(IsAdmin(), F.text == A_ALL)
async def admin_all(m: Message):
    rows = await q_all("SELECT * FROM orders ORDER BY id DESC LIMIT 20")
    if not rows:
        await m.answer("Hali buyurtmalar yo'q.")
        return
    lines = ["<b>📋 Oxirgi 20 ta buyurtma</b>\n"]
    for o in rows:
        lines.append(f"№{o['id']} • {esc(o['full_name'])} • {esc(o['phone'])}\n   {esc(o['title'])} • {STATUS[o['status']]}")
    await m.answer("\n".join(lines))


@router.message(IsAdmin(), F.text == A_STATS)
async def admin_stats(m: Message):
    users = (await q_one("SELECT COUNT(*) c FROM users"))["c"]
    items = (await q_one("SELECT COUNT(*) c FROM items"))["c"]
    by_status = {r["status"]: r["c"] for r in await q_all("SELECT status, COUNT(*) c FROM orders GROUP BY status")}
    total = sum(by_status.values())
    lines = [
        "<b>📊 Statistika</b>\n",
        f"👥 Foydalanuvchilar: <b>{users}</b>",
        f"🪑 Katalogdagi mebellar: <b>{items}</b>",
        f"🧾 Jami buyurtmalar: <b>{total}</b>",
    ]
    for k, v in STATUS.items():
        lines.append(f"   {v}: {by_status.get(k, 0)}")
    await m.answer("\n".join(lines))


# --- Xabar yuborish ---
@router.message(IsAdmin(), F.text == A_BROADCAST)
async def bc_start(m: Message, state: FSMContext):
    await state.set_state(Broadcast.text)
    await m.answer(
        "📢 Barcha foydalanuvchilarga yuboriladigan xabarni yozing (matn yoki rasm+matn).",
        reply_markup=cancel_kb())


@router.message(IsAdmin(), Broadcast.text)
async def bc_send(m: Message, state: FSMContext, bot: Bot):
    await state.clear()
    users = await q_all("SELECT user_id FROM users")
    ok = fail = 0
    status_msg = await m.answer(f"⏳ Yuborilmoqda... (0/{len(users)})")
    for u in users:
        try:
            await bot.copy_message(u["user_id"], m.chat.id, m.message_id)
            ok += 1
        except Exception:  # noqa: BLE001
            fail += 1
        await asyncio.sleep(0.05)
    await status_msg.edit_text(f"✅ Yuborildi: {ok}\n⚠️ Yetib bormadi: {fail}")
    await m.answer("Admin panel", reply_markup=admin_kb())


# --- Zaxira nusxa ---
@router.message(IsAdmin(), Command("backup"))
@router.message(IsAdmin(), F.text == A_BACKUP)
async def backup(m: Message):
    if not os.path.exists(DB_PATH):
        await m.answer("Baza fayli topilmadi.")
        return
    await m.answer_document(
        FSInputFile(DB_PATH, filename=f"shaxob_backup_{datetime.now():%Y%m%d_%H%M}.db"),
        caption="💾 Ma'lumotlar bazasi zaxira nusxasi. Xavfsiz joyda saqlang.")


# ----------------------------- ISHGA TUSHIRISH ------------------------
async def setup_profile(bot: Bot) -> None:
    try:
        await bot.set_my_commands([
            BotCommand(command="start", description="Botni boshlash"),
            BotCommand(command="menu", description="Asosiy menyu"),
            BotCommand(command="catalog", description="Mebellar katalogi"),
            BotCommand(command="order", description="Buyurtma berish"),
            BotCommand(command="contact", description="Aloqa va manzil"),
            BotCommand(command="help", description="Yordam"),
            BotCommand(command="cancel", description="Bekor qilish"),
        ])
        await bot.set_my_name(BRAND)
        await bot.set_my_short_description(
            "🪑 Shaxob Mebel — sifatli mebellar katalogi va buyurtma boti")
        await bot.set_my_description(
            "🪑 Shaxob Mebel rasmiy boti!\n\n"
            "✅ Tayyor mebellar katalogi\n"
            "✅ O'lcham va rang bo'yicha buyurtma\n"
            "✅ Tez va qulay aloqa\n\n"
            "Boshlash uchun START tugmasini bosing 👇")
    except Exception as e:  # noqa: BLE001
        logging.warning("Profilni sozlashda xato: %s", e)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN topilmadi! .env faylini tekshiring.")
    if not ADMIN_IDS:
        logging.warning("ADMIN_IDS ko'rsatilmagan — admin panel ishlamaydi.")
    await init_db()
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)
    await setup_profile(bot)
    logging.info("Bot ishga tushdi ✅")
    await dp.start_polling(bot, drop_pending_updates=True)


if __name__ == "__main__":
    asyncio.run(main())
